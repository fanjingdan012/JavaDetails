package net;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.Semaphore;

public class TestConcurrentRequest {

    // 总的请求个数
    public static final int requestTotal = 23;

    // 同一时刻最大的并发线程的个数
    public static final int concurrentThreadNum = 23;

    public static void main(String[] args) throws Exception {
        ExecutorService executorService = Executors.newCachedThreadPool();
        CountDownLatch countDownLatch = new CountDownLatch(requestTotal);
        Semaphore semaphore = new Semaphore(concurrentThreadNum);
        for (int i = 0; i< requestTotal; i++) {
            executorService.execute(new TaskRunner(semaphore ,countDownLatch,i));
        }
        countDownLatch.await();
        executorService.shutdown();

    }





}