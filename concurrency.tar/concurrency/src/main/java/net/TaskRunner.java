package net;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;

public class TaskRunner implements Runnable{
    static String[] runnableBodies={
            "{\n" +
                    "  \"__metadata\": {\n" +
                    "    \"type\": \"SFOData.PerAddressDEFLT\",\n" +
                    "    \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='home',personIdExternal='pchapman1',startDate=datetime'2013-04-24T00:00:00')\"\n" +
                    "  },\n" +
                    "  \"address1\": \"镇宁路 99号\",\n" +
                    "  \"address2\": null,\n" +
                    "  \"address3\": null,\n" +
                    "  \"addressType\": \"home\",\n" +
                    "  \"city\": \"上海\",\n" +
                    "  \"country\": \"CHN\",\n" +
                    "  \"county\": null,\n" +
                    "  \"personIdExternal\": \"pchapman1\",\n" +
                    "  \"province\": null,\n" +
                    "  \"startDate\": \"/Date(1366761600000)/\",\n" +
                    "  \"state\": \"2017\",\n" +
                    "  \"zipCode\": \"200001\"\n" +
                    "}",

            "{\n" +
                    "    \"__metadata\": {\n" +
                    "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
                    "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='home',personIdExternal='kkkk',startDate=datetime'2019-11-12T00:00:00')\"\n" +
                    "    },\n" +
                    "    \"address2\": null,\n" +
                    "    \"address3\": null,\n" +
                    "    \"addressType\": \"home\",\n" +
                    "    \"city\": null,\n" +
                    "    \"country\": \"USA\",\n" +
                    "    \"county\": null,\n" +
                    "    \"personIdExternal\": \"kkkk\",\n" +
                    "    \"province\": null,\n" +
                    "    \"startDate\": \"/Date(1573516800000)/\",\n" +
                    "    \"state\": \"1968\",\n" +
                    "    \"zipCode\": null\n" +
                    "  }",


            "   { \"__metadata\": {\n" +
                    "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
                    "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='home',personIdExternal='sbaker1',startDate=datetime'2013-04-25T00:00:00')\"\n" +
                    "    },\n" +
                    "    \"address1\": \"1 Zhongguancun Ave\",\n" +
                    "    \"address2\": null,\n" +
                    "    \"address3\": null,\n" +
                    "    \"addressType\": \"home\",\n" +
                    "    \"city\": \"Beijing\",\n" +
                    "    \"country\": \"CHN\",\n" +
                    "    \"county\": null,\n" +
                    "    \"personIdExternal\": \"sbaker1\",\n" +
                    "    \"province\": null,\n" +
                    "    \"startDate\": \"/Date(1366848000000)/\",\n" +
                    "    \"state\": null,\n" +
                    "    \"zipCode\": \"100081\"\n" +
                    "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='home',personIdExternal='eclark1',startDate=datetime'1994-06-03T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"15-71 NCI Tower, No. 12 A Jianguomenwai Ave\",\n" +
            "    \"address2\": null,\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"home\",\n" +
            "    \"city\": \"Beijing\",\n" +
            "    \"country\": \"CHN\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"eclark1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(770601600000)/\",\n" +
            "    \"state\": null,\n" +
            "    \"zipCode\": \"100022\"\n" +
            "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='home',personIdExternal='eclark1',startDate=datetime'2013-04-24T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"马当路 77\",\n" +
            "    \"address2\": null,\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"home\",\n" +
            "    \"city\": \"上海\",\n" +
            "    \"country\": \"CHN\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"eclark1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(1366761600000)/\",\n" +
            "    \"state\": null,\n" +
            "    \"zipCode\": \"200001\"\n" +
            "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='benefits',personIdExternal='rbusch1',startDate=datetime'2001-05-05T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"15-71 NCI Tower, No. 12 A Jianguomenwai Ave\",\n" +
            "    \"address2\": null,\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"benefits\",\n" +
            "    \"city\": \"Beijing\",\n" +
            "    \"country\": \"CHN\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"rbusch1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(989020800000)/\",\n" +
            "    \"state\": null,\n" +
            "    \"zipCode\": \"100022\"\n" +
            "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='home',personIdExternal='rbusch1',startDate=datetime'2013-04-24T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"延安西路 464\",\n" +
            "    \"address2\": null,\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"home\",\n" +
            "    \"city\": \"上海\",\n" +
            "    \"country\": \"CHN\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"rbusch1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(1366761600000)/\",\n" +
            "    \"state\": null,\n" +
            "    \"zipCode\": \"200001\"\n" +
            "  }",
            "{\n" +
                    "    \"__metadata\": {\n" +
                    "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
                    "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='benefits',personIdExternal='shunter1',startDate=datetime'1997-10-02T00:00:00')\"\n" +
                    "    },\n" +
                    "    \"address1\": \"651 Michigan Ave\",\n" +
                    "    \"address2\": \"Floor 23\",\n" +
                    "    \"address3\": null,\n" +
                    "    \"addressType\": \"benefits\",\n" +
                    "    \"city\": \"Chicago\",\n" +
                    "    \"country\": \"USA\",\n" +
                    "    \"county\": null,\n" +
                    "    \"personIdExternal\": \"shunter1\",\n" +
                    "    \"province\": null,\n" +
                    "    \"startDate\": \"/Date(875750400000)/\",\n" +
                    "    \"state\": \"1979\",\n" +
                    "    \"zipCode\": \"60609\"\n" +
                    "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='home',personIdExternal='nbrown1',startDate=datetime'2013-04-24T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"深南大道 18号\",\n" +
            "    \"address2\": null,\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"home\",\n" +
            "    \"city\": \"深圳\",\n" +
            "    \"country\": \"CHN\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"nbrown1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(1366761600000)/\",\n" +
            "    \"state\": \"2037\",\n" +
            "    \"zipCode\": \"518040\"\n" +
            "  }", "{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='benefits',personIdExternal='rfong1',startDate=datetime'2007-03-21T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"Level 11, Aoyama Palacio Tower\",\n" +
            "    \"address2\": null,\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"benefits\",\n" +
            "    \"city\": \"Tokyo\",\n" +
            "    \"country\": \"JPN\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"rfong1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(1174435200000)/\",\n" +
            "    \"state\": null,\n" +
            "    \"zipCode\": \"107-0061\"\n" +
            "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='benefits',personIdExternal='clewis1',startDate=datetime'2002-08-11T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"Bahnhofplatz 2 Mietwagenzentrum\",\n" +
            "    \"address2\": null,\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"benefits\",\n" +
            "    \"city\": \"Munich\",\n" +
            "    \"country\": \"DEU\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"clewis1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(1029024000000)/\",\n" +
            "    \"state\": null,\n" +
            "    \"zipCode\": \"80335\"\n" +
            "  }",           "{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='business',personIdExternal='dthomas1',startDate=datetime'2007-07-01T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"Donceles 99\",\n" +
            "    \"address2\": \"Centro, Cuauhtémoc\",\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"benefits\",\n" +
            "    \"city\": \"México D.F.\",\n" +
            "    \"country\": \"MEX\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"dthomas1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(1183248000000)/\",\n" +
            "    \"state\": null,\n" +
            "    \"zipCode\": \"11560\"\n" +
            "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='business',personIdExternal='mmoore1',startDate=datetime'1994-09-02T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"259 Cochituate Rd\",\n" +
            "    \"address2\": \"Suite 2301\",\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"benefits\",\n" +
            "    \"city\": \"Framingham\",\n" +
            "    \"country\": \"USA\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"mmoore1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(778464000000)/\",\n" +
            "    \"state\": \"1987\",\n" +
            "    \"zipCode\": \"1702\"\n" +
            "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='business',personIdExternal='whickey1',startDate=datetime'2001-11-03T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"Level 57, MLC Centre, 19-29 Martin Place\",\n" +
            "    \"address2\": null,\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"benefits\",\n" +
            "    \"city\": \"Sydney\",\n" +
            "    \"country\": \"AUS\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"whickey1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(1004745600000)/\",\n" +
            "    \"state\": \"5526\",\n" +
            "    \"zipCode\": \"2000\"\n" +
            "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='home',personIdExternal='dnguyen1',startDate=datetime'2013-04-24T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"Schöne Aussicht\",\n" +
            "    \"address2\": \"23\",\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"home\",\n" +
            "    \"city\": \"Hamburg\",\n" +
            "    \"country\": \"DEU\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"dnguyen1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(1366761600000)/\",\n" +
            "    \"state\": \"Hamburg\",\n" +
            "    \"zipCode\": \"22085\"\n" +
            "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='home',personIdExternal='rfehrman1',startDate=datetime'2013-04-24T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"2 PLACE DE LA DEFENSE CNIT\",\n" +
            "    \"address2\": \"BP 210\",\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"home\",\n" +
            "    \"city\": \"La Defense\",\n" +
            "    \"country\": \"FRA\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"rfehrman1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(1366761600000)/\",\n" +
            "    \"state\": \"5410\",\n" +
            "    \"zipCode\": \"92053\"\n" +
            "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='business',personIdExternal='ewhite1',startDate=datetime'1998-08-23T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"Bahnhofplatz 2 Mietwagenzentrum\",\n" +
            "    \"address2\": null,\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"benefits\",\n" +
            "    \"city\": \"Munich\",\n" +
            "    \"country\": \"DEU\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"ewhite1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(903830400000)/\",\n" +
            "    \"state\": null,\n" +
            "    \"zipCode\": \"80335\"\n" +
            "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='business',personIdExternal='jlau1',startDate=datetime'2007-08-24T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"99 rue de Rivoli\",\n" +
            "    \"address2\": null,\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"benefits\",\n" +
            "    \"city\": \"Paris\",\n" +
            "    \"country\": \"FRA\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"jlau1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(1187913600000)/\",\n" +
            "    \"state\": null,\n" +
            "    \"zipCode\": \"75058\"\n" +
            "  }",
            "{\n" +
                    "    \"__metadata\": {\n" +
                    "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
                    "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='business',personIdExternal='nkoo1',startDate=datetime'2007-04-26T00:00:00')\"\n" +
                    "    },\n" +
                    "    \"address1\": \"99 rue de Rivoli\",\n" +
                    "    \"address2\": null,\n" +
                    "    \"address3\": null,\n" +
                    "    \"addressType\": \"benefits\",\n" +
                    "    \"city\": \"Paris\",\n" +
                    "    \"country\": \"FRA\",\n" +
                    "    \"county\": null,\n" +
                    "    \"personIdExternal\": \"nkoo1\",\n" +
                    "    \"province\": null,\n" +
                    "    \"startDate\": \"/Date(1177545600000)/\",\n" +
                    "    \"state\": null,\n" +
                    "    \"zipCode\": \"75058\"\n" +
                    "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='business',personIdExternal='dsmith1',startDate=datetime'2002-10-03T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"Level 11, Aoyama Palacio Tower\",\n" +
            "    \"address2\": null,\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"benefits\",\n" +
            "    \"city\": \"Tokyo\",\n" +
            "    \"country\": \"JPN\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"dsmith1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(1033603200000)/\",\n" +
            "    \"state\": null,\n" +
            "    \"zipCode\": \"107-0061\"\n" +
            "  }",
            "{\n" +
                    "    \"__metadata\": {\n" +
                    "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
                    "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='business',personIdExternal='mlu1',startDate=datetime'2001-08-04T00:00:00')\"\n" +
                    "    },\n" +
                    "    \"address1\": \"Bahnhofplatz 2 Mietwagenzentrum\",\n" +
                    "    \"address2\": null,\n" +
                    "    \"address3\": null,\n" +
                    "    \"addressType\": \"benefits\",\n" +
                    "    \"city\": \"Munich\",\n" +
                    "    \"country\": \"DEU\",\n" +
                    "    \"county\": null,\n" +
                    "    \"personIdExternal\": \"mlu1\",\n" +
                    "    \"province\": null,\n" +
                    "    \"startDate\": \"/Date(996883200000)/\",\n" +
                    "    \"state\": null,\n" +
                    "    \"zipCode\": \"80335\"\n" +
                    "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='business',personIdExternal='asingh1',startDate=datetime'2002-07-06T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"1500 Fashion Island Blvd.\",\n" +
            "    \"address2\": \"Ste. 300\",\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"benefits\",\n" +
            "    \"city\": \"San Mateo\",\n" +
            "    \"country\": \"USA\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"asingh1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(1025913600000)/\",\n" +
            "    \"state\": \"1970\",\n" +
            "    \"zipCode\": \"94404\"\n" +
            "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='business',personIdExternal='dsharp1',startDate=datetime'2007-05-02T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"1500 Fashion Island Blvd.\",\n" +
            "    \"address2\": \"Ste. 300\",\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"benefits\",\n" +
            "    \"city\": \"San Mateo\",\n" +
            "    \"country\": \"USA\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"dsharp1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(1178064000000)/\",\n" +
            "    \"state\": \"1970\",\n" +
            "    \"zipCode\": \"94404\"\n" +
            "  }",
            "{\n" +
                    "    \"__metadata\": {\n" +
                    "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
                    "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='business',personIdExternal='tleonard1',startDate=datetime'2001-06-15T00:00:00')\"\n" +
                    "    },\n" +
                    "    \"address1\": \"1500 Fashion Island Blvd.\",\n" +
                    "    \"address2\": \"Ste. 300\",\n" +
                    "    \"address3\": null,\n" +
                    "    \"addressType\": \"benefits\",\n" +
                    "    \"city\": \"San Mateo\",\n" +
                    "    \"country\": \"USA\",\n" +
                    "    \"county\": null,\n" +
                    "    \"personIdExternal\": \"tleonard1\",\n" +
                    "    \"province\": null,\n" +
                    "    \"startDate\": \"/Date(992563200000)/\",\n" +
                    "    \"state\": \"1970\",\n" +
                    "    \"zipCode\": \"94404\"\n" +
                    "  }","{\n" +
            "    \"__metadata\": {\n" +
            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='business',personIdExternal='mmoos1',startDate=datetime'2001-07-12T00:00:00')\"\n" +
            "    },\n" +
            "    \"address1\": \"1500 Fashion Island Blvd.\",\n" +
            "    \"address2\": \"Ste. 300\",\n" +
            "    \"address3\": null,\n" +
            "    \"addressType\": \"benefits\",\n" +
            "    \"city\": \"San Mateo\",\n" +
            "    \"country\": \"USA\",\n" +
            "    \"county\": null,\n" +
            "    \"personIdExternal\": \"mmoos1\",\n" +
            "    \"province\": null,\n" +
            "    \"startDate\": \"/Date(994896000000)/\",\n" +
            "    \"state\": \"1970\",\n" +
            "    \"zipCode\": \"94404\"\n" +
            "  }"
    };
    static String [] bodies = {
//            "{\n" +
//            "    \"__metadata\": {\n" +
//            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
//            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='business',personIdExternal='sleung1',startDate=datetime'1992-10-16T00:00:00')\"\n" +
//            "    },\n" +
//            "    \"address1\": \"#803, 8th FL., PAN-PACIFIC B/D, 197-21\",\n" +
//            "    \"address2\": \"Guro-dong, Guro-gu\",\n" +
//            "    \"address3\": null,\n" +
//            "    \"addressType\": \"business\",\n" +
//            "    \"city\": \"Seoul\",\n" +
//            "    \"country\": \"KOR\",\n" +
//            "    \"county\": null,\n" +
//            "    \"personIdExternal\": \"sleung1\",\n" +
//            "    \"province\": null,\n" +
//            "    \"startDate\": \"/Date(719193600000)/\",\n" +
//            "    \"state\": null,\n" +
//            "    \"zipCode\": \"123\"\n" +
//            "  }",
//            "{\n" +
//            "    \"__metadata\": {\n" +
//            "      \"type\": \"SFOData.PerAddressDEFLT\",\n" +
//            "      \"uri\": \"https://localhost:443/odata/v2/PerAddressDEFLT(addressType='business',personIdExternal='jwoodard1',startDate=datetime'1997-05-11T00:00:00')\"\n" +
//            "    },\n" +
//            "    \"address1\": \"#803, 8th FL., PAN-PACIFIC B/D, 197-21\",\n" +
//            "    \"address2\": \"Guro-dong, Guro-gu\",\n" +
//            "    \"address3\": null,\n" +
//            "    \"addressType\": \"benefits\",\n" +
//            "    \"city\": \"Seoul\",\n" +
//            "    \"country\": \"KOR\",\n" +
//            "    \"county\": null,\n" +
//            "    \"personIdExternal\": \"jwoodard1\",\n" +
//            "    \"province\": null,\n" +
//            "    \"startDate\": \"/Date(863308800000)/\",\n" +
//            "    \"state\": null,\n" +
//            "    \"zipCode\": null\n" +
//            "  }"
            };
    Semaphore semaphore;
    CountDownLatch countDownLatch;
    int i;

    public TaskRunner(Semaphore semaphore, CountDownLatch countDownLatch, int i) {
        this.semaphore=semaphore;
        this.countDownLatch=countDownLatch;
        this.i=i;
    }

    @Override
    public void run() {

            try {
                semaphore.acquire();
                String result = HttpClientUtil.sendPost(runnableBodies[i]);
                System.out.println("result:"+ result);
                semaphore.release();
            } catch (Exception e) {
                System.out.println("exception"+ e);
            }
            countDownLatch.countDown();

    }
    public static void main(String[] args){
        System.out.println(runnableBodies[1]);
    }
}
