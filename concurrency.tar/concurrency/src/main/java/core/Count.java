package core;

public class Count {
    private int num;  
    public void increment() {  
        num++;  
    }  
    public int get() {  
        return num;  
    }  
}  